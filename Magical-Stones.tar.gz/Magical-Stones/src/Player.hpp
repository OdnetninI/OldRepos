#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "include.hpp"

class Player
{
    private:
        int x,y;
        bool female;

        // Owned Creatures at current party
        Creature Creature1;
        Creature Creature2;
        Creature Creature3;
        Creature Creature4;
        Creature Creature5;
        Creature Creature6;

    public:
        void Create (bool _female);
        void Control ();
        void SetXY (int _x, int _y);
        void Render ();
        Creature GetCreature (int num);
        void SetCreature (int num, Creature creature);

};

#endif // __PLAYER_H__
