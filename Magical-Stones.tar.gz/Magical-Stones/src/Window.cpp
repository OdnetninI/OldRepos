#include "include.hpp"

void Window::Create (int width, int height, string title)
{
    window.create(sf::VideoMode(width, height),title.c_str());
}

void Window::SetTitle (string title)
{
    window.setTitle (title.c_str());
}

void Window::SetSize (int width, int height)
{
    window.setSize(sf::Vector2u(width,height));
}

bool Window::IsOpen () {return window.isOpen();}
void Window::Close () {window.close();}
void Window::Clear () {window.clear();}
void Window::Update () {window.display();}
void Window::Draw (sf::Sprite sprite) {window.draw(sprite);}
bool Window::PollEvent(sf::Event &event) {return window.pollEvent(event);}
