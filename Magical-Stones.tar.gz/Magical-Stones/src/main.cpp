#include "include.hpp"

int main()
{
    Window MainWindow;
    MainWindow.Create(SCREEN_X,SCREEN_Y,"Magical Stones"); //25 x 18 tiles de 32x32

    Sprite Hero;
    Hero.Create("Data/testing.png",0,0,50,50,32,32);

    int px = 640;
    int py = 320;

    Tilemap Map;
    Map.Load("Data/tileset.png","Data/MAP");

	// Start the game loop
    while (MainWindow.IsOpen())
    {
        // Process events
        sf::Event event;
        while (MainWindow.PollEvent(event))
        {
            // Close window : exit
            if (event.type == sf::Event::Closed)
                MainWindow.Close();
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
        {
            px--;
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
        {
            px++;
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
        {
            py--;
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
        {
            py++;
        }

        // Clear screen
        MainWindow.Clear();

        Map.Move(px,py);
        Map.Render(MainWindow);

        Hero.Render(MainWindow);

        // Update the window
        MainWindow.Update();
    }

    return EXIT_SUCCESS;
}
