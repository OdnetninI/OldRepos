#ifndef __SPRITE_H__
#define __SPRITE_H__

#include "include.hpp"

class Sprite
{
    private:
        sf::Texture texture;
        sf::Sprite sprite;
    public:
        void Create (string texture, int framex, int framey, int x, int y, int width, int hight);
        void LoadTex (string texture);
        void SetFrame (int framex, int framey, int width, int height);
        void Move (int x, int y);
        void Render (Window &window);
};

#endif // __SPRITE_H__
