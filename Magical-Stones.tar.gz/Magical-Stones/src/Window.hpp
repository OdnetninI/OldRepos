#ifndef __WINDOW_H__
#define __WINDOW_H__

#include "include.hpp"

class Window
{
    private:
        sf::RenderWindow window;
    public:
        void Create (int width, int height, string title);  // Create a new Window
        void SetTitle (string title);                       // Set a new Title
        void SetSize (int width, int height);               // Set a new Size
        bool IsOpen ();
        void Close ();
        void Clear ();
        void Update ();                                     // Redraw the screen
        void Draw (sf::Sprite sprite);
        bool PollEvent(sf::Event &event);                    // Check Pile of Events
};

#endif // __WINDOW_H__
