#ifndef __TILEMAP_H__
#define __TILEMAP_H__

#include "include.hpp"

class Tilemap
{
    private:
        Tileset tileset;
        ifstream mapfile;
        char * buffer;
        int ** MAP;
        int RenderMAP[TILE_WIDTH+2][TILE_HEIGHT+2];
        int px, py;
        int w, h;
    public:
        void Load (string tiles, string file); // +2 External scroll tiles
        void Render (Window &window);
        void Move (int _x, int _y);
};


#endif // __TILESET_H__

