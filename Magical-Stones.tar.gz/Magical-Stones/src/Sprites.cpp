#include "include.hpp"

void Sprite::Create (string texture, int framex, int framey, int x, int y, int width, int height)
{
    LoadTex (texture);
    SetFrame (framex, framey, width, height);
    Move (x, y);
}

void Sprite::LoadTex (string tex)
{
    texture.loadFromFile(tex.c_str());
    sprite.setTexture(texture);
}

void Sprite::SetFrame (int framex, int framey, int width, int height)
{
    sprite.setTextureRect(sf::IntRect(framex, framey, width, height));
}

void Sprite::Move (int x, int y)
{
    sprite.setPosition(sf::Vector2f(x, y));
}

void Sprite::Render (Window &window)
{
    window.Draw(sprite);
}
