#ifndef __CREATURE_H__
#define __CREATURE_H__

#include "include.hpp"

class Creature
{

};

#endif // __CREATURE_H__
