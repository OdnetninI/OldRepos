#ifndef __TILESET_H__
#define __TILESET_H__

#include "include.hpp"

class Tileset
{
    private:
        int Map[TILE_WIDTH+2][TILE_HEIGHT+2];
        Sprite pointer;
        int x, y;
    public:
        void Load (string tileset, int _Map[TILE_WIDTH+2][TILE_HEIGHT+2]); // +2 External scroll tiles
        void Render (Window &window);
        void NewMap (int _Map[TILE_WIDTH+2][TILE_HEIGHT+2]);
        void Move (int _x, int _y);
};


#endif // __TILESET_H__
