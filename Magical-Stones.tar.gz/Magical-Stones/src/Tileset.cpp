#include "include.hpp"

void Tileset::Load(string tileset, int _Map[TILE_WIDTH+2][TILE_HEIGHT+2])
{
    pointer.LoadTex(tileset);
    Move(0,0);
    NewMap(_Map);
}

void Tileset::Move(int _x, int _y)
{
    x = _x;
    y = _y;

    if(x >= TILE_SIZE)
        x = x%TILE_SIZE;
    if(y >= TILE_SIZE)
        y = y%TILE_SIZE;

    if(x <= -TILE_SIZE)
        x = x%TILE_SIZE;
    if(y <= -TILE_SIZE)
        y = y%TILE_SIZE;
}

void Tileset::NewMap (int _Map[TILE_WIDTH+2][TILE_HEIGHT+2])
{
    for (int i = 0; i < TILE_WIDTH+2;i++)
    {
        for (int j = 0; j < TILE_HEIGHT+2; j++)
            Map[i][j] = _Map[i][j];
    }
}

void Tileset::Render (Window &window)
{
    for (int i = 0; i < TILE_WIDTH+2;i++)
    {
        for (int j = 0; j < TILE_HEIGHT+2; j++)
        {
            pointer.SetFrame(Map[i][j]*TILE_SIZE,0,TILE_SIZE,TILE_SIZE);
            pointer.Move(((i-1)*TILE_SIZE)+x,((j-1)*TILE_SIZE)+y);
            pointer.Render(window);
        }
    }
}
