#include "include.hpp"

void Tilemap::Load(string tiles, string file)
{
    for (int i = 0; i < TILE_WIDTH+2;i++)
    {
        for (int j = 0; j < TILE_HEIGHT+2; j++)
            RenderMAP[i][j] = 0;
    }
    tileset.Load(tiles, RenderMAP);

    mapfile.open(file.c_str(), ios::binary);
    int length;
    mapfile.seekg (0, mapfile.end);
    length = mapfile.tellg();
    mapfile.seekg (0, mapfile.beg);

    buffer = new char[length];
    mapfile.read (buffer,length);
    mapfile.close();

    w = (int)buffer[1];
    w |= (int)buffer[0] << 8;
    h = (int)(length-2)/w;

    cout << w << endl;
    cout << h << endl;

    MAP = new int*[w];
    for (int i = 0; i < w; i++)
        MAP[i] = new int[h];

    for (int j = 0; j < h; j++)
    {
        for (int i = 0; i < w; i++)
            MAP[i][j] = (int)buffer[i+(j*w)+2];
    }

    delete[] buffer;
}

void Tilemap::Move (int _x, int _y)
{
    px = _x;
    py = _y;
    tileset.Move(-_x, -_y);
}

void Tilemap::Render (Window &window)
{
    // Consideramos que PX y PY son coordenadas en el centro de la pantalla
    int tx = (px/TILE_SIZE)-(TILE_WIDTH/2);
    int ty = (py/TILE_SIZE)-(TILE_HEIGHT/2);

    if (tx < 0) tx = 0;
    if (ty < 0) ty = 0;

    if (tx > w-(TILE_WIDTH)-2) tx = w-(TILE_WIDTH)-2;
    if (ty > h-(TILE_HEIGHT)-2) ty = h-(TILE_HEIGHT)-2;


    for (int j = 0; j < TILE_HEIGHT+2; j++)
    {
        for (int i = 0; i < TILE_WIDTH+2;i++)
        {
            RenderMAP[i][j] = MAP[tx+i][ty+j];
        }
    }

    tileset.NewMap(RenderMAP);
    tileset.Render(window);
}
