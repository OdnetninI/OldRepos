#ifndef __INCLUDES_H__
#define __INCLUDES_H__

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>

#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

#define TILE_SIZE   32
#define TILE_WIDTH  25
#define TILE_HEIGHT 18
#define SCREEN_X    TILE_SIZE*TILE_WIDTH
#define SCREEN_Y    TILE_SIZE*TILE_HEIGHT

// ENGINE
#include "Window.hpp"
#include "Sprites.hpp"
#include "Tileset.hpp"
#include "TileMap.hpp"
#include "CreatureData.hpp"
#include "Player.hpp"
// GAME


#endif // __INCLUDES_H__
