# Magical Stones
This is a RPG Monsters game started by OdnetninI

## Licenses
· Code: GPLv3

· SFML: Zlib
