#ifndef __ANIMATION_HPP__
#define __ANIMATION_HPP__

typedef struct S_Animation {
  uint16_t    frame;
  sf::Time    time;
} Animation;

#endif // __ANIMATION_HPP__
