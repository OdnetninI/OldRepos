#include <SFML/Graphics.hpp>
#include "Game.hpp"

int main (int argc, char* argv[]) {
  return Game().run();
}
