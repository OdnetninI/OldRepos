/* 
    This file is part of C-Utils.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.

    OdnetninI - 2017
*/

#ifndef __CUTILS_H__2017__
#define __CUTILS_H__2017__

// Check if GNUC
#ifndef __GNUC__
#warning Some functions might not work
#endif /* __GNUC__ */

// Boolean alternative
typedef unsigned char CBool;
#define ctrue  1
#define cfalse 0

// Debug Crash
#define CRASH() do{ ((void(*)())0)(); } while(0)

// Branch Prediction
#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

// Get offset of struct
#define OFFSETOF(type, element) ((size_t)&(((type *)0)->element))

// Text Join
#define JOIN(x, y) x ## y
#define JOIN_1(x, y) JOIN(#x, y)
#define JOIN_2(x, y) JOIN(x, #y)
#define JOIN_3(x, y) JOIN(x, y)

// Defer (Experimental) (Only for block of codes)
#define defer_(x) do{}while(0); \
        auto void _dtor1_##x(); \
        auto void _dtor2_##x(); \
        int __attribute__((cleanup(_dtor2_##x))) _dtorV_##x=2; \
        void _dtor2_##x(){if(_dtorV_##x==1)return _dtor1_##x();};_dtorV_##x=1;\
        void _dtor1_##x()
#define defer__(x) defer_(x)
#define defer defer__(__COUNTER__)

// Swap two variable without a third one
#define SWAP(x, y) do{ x ^= y; y ^= x; x ^= y; }while(0)

// Variable Comparation
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#define EQU(x, y) ((x) == (y))
#define MAXEQ(x, y) ((x) >= (y))
#define MINEQ(x, y) ((x) <= (y))

// No-Return (for functions that never returns like exit)
#define FUNC_NO_RETURN __attribute__((noreturn))

// For only numeric functions without side effects (only affected by parameters)
#define FUNC_CONST __attribute__((const))

// For only numeric functions without side effects (only affected by parameters and globar variables)
#define FUNC_PURE __attribute__((pure))

// Force inline function
#define FUNC_INLINE __attribute__((always_inline))

// Align Function in memory
#define FUNC_ALIGN(x) __attribute__((aligned(x)))

// Align Variables in memory
#define ALIGN(x) __attribute__((aligned(x)))

// Error printf
#define eprintf(...) fprintf (stderr, __VA_ARGS__)

// Operators
#define and &&
#define or ||
#define xor ^
#define not !
#define is ==
#define isnt !=
#define in ,
#define _or |
#define _and &
#define bit(n,b) ((n >> b) _and 1)

#define nif(x) if(!(x))
#define until(x) while(!(x))

// Allocators
#define new_2(t, n) (t *) malloc((n)*sizeof(t))
#define new_1(t) new_2(t, 1)
#define new_get(_1, _2, name, ...) name
#define new(...) new_get(__VA_ARGS__ ,new_2, new_1)(__VA_ARGS__)
#define delete(x) free(x)

// Logging
#define log(fmt, ...) printf("%s:%d: " fmt "\n", __FILE__, __LINE__,__VA_ARGS__)
#define iflog(cond, fmt,...) do{if (cond) log(fmt, __VA_ARGS__);}while(0)

#define logInt(x) printf("%s = %d\n", #x, (x))
#define logStr(x) printf("%s = %s\n", #x, (x))
  
#endif /* __CUTILS_H__2017__ */
