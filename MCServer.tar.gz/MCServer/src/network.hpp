#ifndef __IRC_HPP__
#define __IRC_HPP__

#include <SFML/Network.hpp>
#include <cstring>
#include "Protocol/Package.hpp"

class Network {
  private:
    sf::TcpSocket socket;
    sf::TcpListener listener;

  public:
    Network();
    ~Network();

    void connect ();
    Package* recieve();
    bool sendData (Package* packet);
};

#endif /* __IRC_HPP__ */
