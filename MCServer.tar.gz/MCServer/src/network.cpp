#include "network.hpp"
#include <iostream>

Network::Network() {}

Network::~Network() {
  this->socket.disconnect();
}

void Network::connect() {
  if (this->listener.listen(25565) != sf::Socket::Done) {
    std::cerr << "ERROR LISTENING CLIENTS" << std::endl;
    return;
  }
  if (this->listener.accept(this->socket) != sf::Socket::Done) {
    std::cerr << "ERROR ACCEPTING CLIENT" << std::endl;
    return;
  }
}

Package* Network::recieve () {
  char* data = new char[2048];
  uint64_t t;
  if (this->socket.receive(data, 2048, t) != sf::Socket::Done) {
    std::cerr << "ERROR RECEIVING DATA" << std::endl;
    return nullptr;
  }
  Package* packet = new Package();
  packet->parse(data, t);
  return packet;
}

bool Network::sendData (Package* packet) {
  char bytes[packet->getLength()+1];
  bytes[0] = packet->getLength();
  bytes[1] = packet->getPacketID();
  for (uint32_t i = 2; i < packet->getLength(); i++) {
    bytes[i] = packet->getPacket()->getData()[i-2];
  }
  uint64_t t = 0;
  if (this->socket.send(bytes, packet->getLength()+1, t) != sf::Socket::Done) {
    std::cerr << "ERROR SENDING DATA: " << (char*)packet->getPacket()->getData() << std::endl;
    return false;
  }
  return true;
}
