#include "network.hpp"
#include <iostream>
#include <thread>

Network net;

void terminalCommands () {
  std::string command = "";
  while (true) {
    std::cin >> command;
    if (command == "exit") exit(0);
  }
}

void botLoop () {
  // while (true) {
    std::cout << "Waiting Data" << std::endl;
    Package* packet = net.recieve();
    std::cout << "Size: " << packet->getLength() << std::endl;
    std::cout << "PacketID: " << packet->getPacketID() << std::endl;
    std::cout << "Packet Raw:" << packet->getPacket() << std::endl;
    delete packet;

    std::cout << "Waiting Data" << std::endl;
    packet = net.recieve();
    std::cout << "Size: " << packet->getLength() << std::endl;
    std::cout << "PacketID: " << packet->getPacketID() << std::endl;
    std::cout << "Packet Raw:" << packet->getPacket() << std::endl;
    delete packet;
//172.22.74.44:25565
    packet = new Package();
    Packet* pack = new Packet();
    uint8_t x[] = {0x10,0x82,0x36,0x42,0x3c,0x0c,0xe5,0x46,0xef,0x97,0x0c,0xd9,0x33,0x7c,0xa3,0xeb,0x05,0x09,0x4f,0x64,0x6e,0x65,0x74,0x6e,0x69,0x6e,0x49};
    pack->setDataAndSize((char*)x, sizeof(x));
    packet->setPacket(pack);
    packet->setPacketID(2);
    packet->setLength(sizeof(x)+1);
    net.sendData(packet);
    std::cout << "Size: " << packet->getLength() << std::endl;
    std::cout << "PacketID: " << packet->getPacketID() << std::endl;
    std::cout << "Packet Raw:" << packet->getPacket() << std::endl;
    delete packet;

    while (1) {
      std::cout << "Waiting Data" << std::endl;
      packet = net.recieve();
      std::cout << "Size: " << packet->getLength() << std::endl;
      std::cout << "PacketID: " << packet->getPacketID() << std::endl;
      std::cout << "Packet Raw:" << packet->getPacket() << std::endl;
      delete packet;
    }
  // }
}

int main () {
  net.connect();
  std::cout << "Connected" << std::endl;
  std::thread terminal(terminalCommands);
  std::thread bot(botLoop);

  terminal.join();
  bot.join();

  return 0;
}
