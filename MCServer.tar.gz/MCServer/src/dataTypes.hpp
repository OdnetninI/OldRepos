#ifndef __DATA_TYPES_HPP__
#define __DATA_TYPES_HPP__ 

namespace DataTypes {

  // Rename primitive data types
  typedef     bool            Boolean;
  typedef     int8_t          Byte;
  typedef     uint8_t         UByte;
  typedef     int16_t         Short;
  typedef     uint16_t        UShort;
  typedef     int32_t         Int;
  typedef     int64_t         Long;
  typedef     float           Float;
  typedef     double          Double;
  typedef     std::string     String;
  typedef     String          Chat;
  typedef     int32_t         VarInt;
  typedef     int64_t         VarLong;

};

#endif /* __DATA_TYPES_HPP__ */
