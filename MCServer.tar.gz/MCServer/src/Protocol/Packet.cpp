#include "Protocol/Packet.hpp"
#include "Protocol/DataTypes.hpp"

Packet* Packet::parsePacket(const char* data, uint32_t packetID, uint32_t size) {
  // NEED TO HANDLE Protocol DFA
  switch (packetID) {
    case 0: return new PacketHandShake(data, size);
    default: return new Packet(data, size);
  }
}

Packet::Packet() {
  this->data = nullptr;
  this->packetSize = 0;
}

Packet::Packet(const char* data, uint32_t packetSize) {
  this->data = new char[packetSize];
  for (uint32_t i = 0; i < packetSize; i++)
    this->data[i] = data[i];
  this->packetSize = packetSize;
}

Packet::~Packet() {
  if (this->data) delete this->data;
}

uint32_t Packet::getPacketSize() {
  return this->packetSize;
}

char* Packet::getData() {
  return this->data;
}

std::ostream& operator<< (std::ostream& cout, Packet* packet) {
  for (uint32_t i = 0; i < packet->getPacketSize(); i++)
    cout <<(packet->getData())[i];
  return cout;
}

PacketHandShake::~PacketHandShake() {
  if (this->ip) delete this->ip;
}

void Packet::setDataAndSize(const char* data, uint32_t size) {
  this->data = new char[size];
  for (uint32_t i = 0; i < size; i++)
    this->data[i] = data[i];
  this->packetSize = size;
}

PacketHandShake::PacketHandShake(const char* data, uint32_t size) {
  this->packetSize = size;
  this->data = new char[size];
  for (uint32_t i = 0; i < size; i++)
    this->data[i] = data[i];

  uint8_t next = 0;
  this->protocol = DataTypes::parseVarInt(data, size, next);
  data += next;
  size -= next;
  this->ipLength = DataTypes::parseVarInt(data, size, next);
  data += next;
  size -= next;
  this->ip = new char[this->ipLength+1];
  for (uint32_t i = 0; i < this->ipLength; i++)
    this->ip[i] = data[i];
  this->ip[this->ipLength] = '\0';
  next = this->ipLength;
  data += next;
  size -= next;
  this->port = (((uint8_t)data[0]) << 8) | ((uint8_t)data[1]);
  next = 2;
  data += next;
  size -= next;
  this->nextState = DataTypes::parseVarInt(data, size, next);
}

uint32_t PacketHandShake::getProtocol() {
  return this->protocol;
}
char* PacketHandShake::getIp() {
  return this->ip;
}
uint32_t PacketHandShake::getIpLength() {
  return this->ipLength;
}
uint32_t PacketHandShake::getNexState() {
  return this->nextState;
}
uint16_t PacketHandShake::getPort() {
  return this->port;
}
