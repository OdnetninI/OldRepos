#include "Protocol/Client.hpp"

Client::Client() {
  this->socket = nullptr;
}

Client::~Client() {
  if (this->socket) {
    this->socket 
    delete this->socket;
  }
}

Client::Client(sf::TcpSocket* socket) {
  this->socket = socket;
}

void Client::setSocket(sf::TcpSocket* socket) {
  this->socket = socket;
}

sf::TcpSocket* Client::getSocket() {
  return this->socket;
}

void Client::sendPackage(Package* package) {
      
}
