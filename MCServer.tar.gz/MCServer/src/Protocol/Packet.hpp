#ifndef __PACKET_HPP__
#define __PACKET_HPP__

#include <cstdint>
#include <iostream>

class Packet {
  protected:
    uint32_t packetSize;
    char* data;
  public:
    Packet();
    Packet(const char* data, uint32_t packetSize);
    ~Packet();
    uint32_t getPacketSize();
    char* getData();
    static Packet* parsePacket(const char* data, uint32_t packetID, uint32_t size);
    void setDataAndSize(const char* data, uint32_t size);
};

std::ostream& operator<< (std::ostream& cout, Packet* packet) ;

class PacketHandShake : public Packet{
  private:
    char* ip;
    uint32_t ipLength;
    uint16_t port;
    uint32_t nextState;
    uint32_t protocol;
  public:
    PacketHandShake(const char* data, uint32_t size);
    ~PacketHandShake();
    char* getIp();
    uint32_t getIpLength();
    uint16_t getPort();
    uint32_t getNexState();
    uint32_t getProtocol();
};

#endif /* __PACKET_HPP__ */
