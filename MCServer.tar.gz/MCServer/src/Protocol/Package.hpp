#ifndef __PACKAGE_HPP__
#define __PACKAGE_HPP__

#include "Packet.hpp"
#include <cstdint>

class Package {
  private:
    uint32_t length;
    uint32_t packetID;
    Packet* packet;
  public:
    Package();
    ~Package();

    void parse(const char* data, uint32_t size);
    void setLength(uint32_t length);
    void setPacketID(uint32_t packetID);
    void setPacket(Packet* packet);

    uint32_t getLength();
    uint32_t getPacketID();
    Packet* getPacket();

    char* disParse();
};

#endif /* __PACKAGE_HPP__ */
