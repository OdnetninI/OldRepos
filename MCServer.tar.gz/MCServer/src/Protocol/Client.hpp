#ifndef __CLIENT_HPP__
#define __CLIENT_HPP___

#include <SFML/Network.hpp>
#include "Protocol/Package.hpp"

class Client {
  private:
    sf::TcpSocket* socket;
    
  public:
    Client();
    Client(sf::TcpSocket* socket);
    ~Client();

    void setSocket(sf::TcpSocket* socket);
    sf::TcpSocket* getSocket();

    void update();

    void sendPackage(Package* package);
};

#endif /* __CLIENT_HPP__ */
