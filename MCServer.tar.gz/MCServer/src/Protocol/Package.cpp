#include "Protocol/Package.hpp"
#include "Protocol/DataTypes.hpp"

Package::Package() {
  this->length = 0;
  this->packetID = 0;
  this->packet = nullptr;
}

Package::~Package() {
  if (this->packet)
    delete this->packet;
}

void Package::setLength(uint32_t length) {
  this->length = length;
}

void Package::setPacketID(uint32_t packetID) {
  this->packetID = packetID;
}

void Package::setPacket(Packet* packet) {
  this->packet = packet;
}

uint32_t Package::getLength() {
  return this->length;
}

uint32_t Package::getPacketID() {
  return this->packetID;
}

Packet* Package::getPacket() {
  return this->packet;
}

void Package::parse(const char* data, uint32_t size) {
  uint8_t next = 0;
  this->length = DataTypes::parseVarInt(data, size, next);
  data += next;
  size -= next;
  this->packetID = DataTypes::parseVarInt(data, size, next);
  data += next;
  size -= next;
  this->packet = Packet::parsePacket(data, this->packetID, size);
}

char* Package::disParse() {
    
}

