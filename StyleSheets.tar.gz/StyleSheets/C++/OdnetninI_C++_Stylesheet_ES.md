# OdnetninI C++ Stylesheet
### Nombrado
#### Funciones
- Los nombres de las funciones se escriben en minúsculas.

  ```c++
  void function();
  ```
- Si el nombre de la función se indica con varias palabras, cada una empezará con mayúscula sin incluir la primera.

  ```c++
  void functionMake();
  ```

#### Variables
- Todas las variables se escriben en minúscula, normalmente empezando por letras y no por símbolos especiales.

  ```c++
  int variable = 0;
  ```

- Si la variable se describe usando varias palabras, estas empezarán en mayúscula sin incluir la primera.

  ```c++
  int variableSpecial = 0;
  ```

- Todas las variables que tenga un solo carácter o una '\_' seguida de un carácter, será considerado un índice.

  ```c++
  int i = 0;
  int _i = -1;
  ```

- Las variables que pertenecen a una clase podrán ser escritas con el prefijo 'm\_', pero esto no es necesario, siempre y cuando se use `this->` para referirse a ella. (Se debe especificar en un comentario encima de la clase si se opta por 'm\_').

#### Clases
- Los nombres de las clases se escribirán con la primera letra en mayúscula. `class Test;`
- Si el nombre se describe usando varias palabras, cada palabra empezará en mayúscula. `class TestClass;`

#### Estructuras
- Las estructuras se nombraran con el nombre del tipo de dato que representan (o el abstraido) precedido de al menos una '\_'.

#### Constantes
- Las constantes se escribirán en mayúscula. `#define FIVE 5`
- Si las constante se define con varias palabras, se usarán '\_' como separadores. `#define FIVE_HANDS 55`

#### Ficheros
- Los ficheros de código fuente se nombrarán con el nombre de la clase (si representa una clase), o en su defecto con el nombre más cercano a la funcionalidad o dato que representa.
- Las extensiones serán `.cpp` para código fuente y `.hpp` para cabeceras. En caso de tener código 'C', los ficheros serán `.c` y `.h`.

### Sistema de directorios
- El directorio 'src' incluirá tanto el código fuente como las cabeceras.
- A decisión del proyecto se usarán subdirectorios o no.
- La documentación (en caso de existir), se dispondrá en un directorio llamado docs en la raíz del proyecto.
- En caso de necesitar archivos en tiempo de ejecución, se usará una carpeta en la raíz del proyecto con el nombre de 'Data'

### Ficheros Cabecera
- Las cabeceras tendrán siempre una sentencia:
  ```c++
  #ifndef CONSTANTE
  #define CONSTANTE

  #endif /* CONSTANTE */
  ```
- Dicha constante será escrita como cualquier otra constante, precedida de 2 '\_' y seguida de '\_HPP\_\_', en caso de ser mayormente código 'C', la constante contendrá '\_H\_\_' en lugar de '\_HPP\_\_'.
- No existirá una cabecera común a todas, pero si se permite si la mayor parte del código es código 'C'.

### Constantes
- De forma habitual se usará `#define` para definir constantes, sin embargo, en caso de ser necesario, cualquier variable se considerará constante si se nombra con la reglas de las constantes. El uso de la palabra `const` no es obligatorio.

### Tabulador vs Espacios
- Por defecto se usarán 2 espacios en lugar de un tabulador, sin embargo.
- En caso de usar tabulador, hay que tener en cuenta que se va a interpretar como 2 espacios.

### Política de llaves
- Las llaves NUNCA empezarán en una nueva línea, siempre al final de la existente.
- La llave de cierre se estará en una nueva linea, NUNCA al principio de otra cosa.
- La llave de cierre, estará tabulada al mismo nivel que la sentencia que abre la llave.
- Excepcionalmente en partes suficientemente pequeñas, como asignacion o suma de índices, se permite poner las 2 llaves en la MISMA linea. (Recomendado no usarlo)

### Main
- La llamada del main se realizará siempre con este esquema:

  ```c++
  int main (int argc, char* argv[])
  ```

- En caso de ser necesario, se puede incorporar el tercer argumento a la definición.

### Includes
- Se usarán siempre carpetas hacia delante, nunca '..'
- En la medida de lo posible, primero se podrán los includes del sistema o globales, y después los del proyecto.

### Política de If, If-Else, If-ElseIf
- Depués de la palabra reservada 'if' o 'else', se deja un espacio, antes de abrir paréntesis. `if (condition);`
- Si el bloque de sentencias a ejecutar es de 1 sentencia, se pondrá sin llaves en la misma linea, si esta es más larga que el if, se escribirá en una nueva linea en el siguiente nivel de tabulación del if.

  ```c++
  if (condition) statement;
  if (condition)
    veryLargeStatementForThisIF;
  ```
- La palabra 'else', o el conjunto 'else if', NUNCA tendrá una llave delante, debe ser siempre escrito en una linea nueva.

  ```c++
  if (condition) {
    [...]
  }
  else if {
    [...]
  }
  else {
    [...]
  }
  ```

### Excepciones
- Se prohibe el uso de excepciones, a excepción de partes relacionadas con conexiones.
- Todas aquellas funciones que puedan dar alguna excepción, la cabecera tendrá 'noexcept', o al menos incluir un método que no devuelva excepciones.

### Manejo de Errores
- Al no disponer de excepciones, los errores serán manejados por funciones que devuelven códigos de error. Por legibilidad se recomienda usar constantes y una función que convierta ese número en una texto.
- Dichas funciones manejadoras de errores, pueden tratar el error y seguir con la ejecución.

### Clases
- A la hora de definir una clase, primero se pondrán todos los aributos privados seguido de las funciones que también lo sean. Luego las protegidas, si es necesario, y por último las públicas. Siempre con el mismo diseño de primero atributo y luego métodos.
- El apartado de protegido no es obligatorio escribirlo, pero el de público y privado si.

  ```c++
  class Clase {
    public:
      // Atributos

      // Métodos

    protected:
      // Atributos

      // Métodos

    private:
      // Atributos

      // Métodos
  };
  ```
