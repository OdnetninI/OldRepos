﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Minecraft_Level_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int x = int.Parse(numericUpDown1.Value.ToString());
            int y = int.Parse(numericUpDown2.Value.ToString());
            double next = 0, next2 = 0;
            if (x >= 0 && x <= 15)
            {
                label4.Text = (2 * x + 7).ToString();
                next = ((x * x + 6 * x));
            }
            if (x >= 16 && x <= 30)
            {
                label4.Text = (5 * x - 38).ToString();
                next = ((2.5 * x * x - 40.5 * x + 360));
            }
            if (x >= 31)
            {
                label4.Text = (9 * x - 158).ToString();
                next = ((4.5 * x * x - 162.5 * x + 2220));
            }

            if (y >= 0 && y <= 15)
            {
                next2 = ((y * y + 6 * y));
            }
            if (y >= 16 && y <= 30)
            {
                next2 = ((2.5 * y * y - 40.5 * y + 360));
            }
            if (y >= 31)
            {
                next2 = ((4.5 * y * y - 162.5 * y + 2220));
            }

            label6.Text = (next - next2).ToString();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            int x = int.Parse(numericUpDown1.Value.ToString());
            int y = int.Parse(numericUpDown2.Value.ToString());
            double next = 0, next2 = 0;
            if (x >= 0 && x <= 15)
            {
                label4.Text = (2 * x + 7).ToString();
                next = ((x * x + 6 * x));
            }
            if (x >= 16 && x <= 30)
            {
                label4.Text = (5 * x - 38).ToString();
                next = ((2.5 * x * x - 40.5 * x + 360));
            }
            if (x >= 31)
            {
                label4.Text = (9 * x - 158).ToString();
                next = ((4.5 * x * x - 162.5 * x + 2220));
            }

            if (y >= 0 && y <= 15)
            {
                next2 = ((y * y + 6 * y));
            }
            if (y >= 16 && y <= 30)
            {
                next2 = ((2.5 * y * y - 40.5 * y + 360));
            }
            if (y >= 31)
            {
                next2 = ((4.5 * y * y - 162.5 * y + 2220));
            }

            label6.Text = (next - next2).ToString();
        }
    }
}
