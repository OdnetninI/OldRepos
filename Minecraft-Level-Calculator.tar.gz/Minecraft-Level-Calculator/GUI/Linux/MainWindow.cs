using System;
using Gtk;

public partial class MainWindow: Gtk.Window
{	
	public MainWindow (): base (Gtk.WindowType.Toplevel)
	{
		Build ();
	}
	
	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}
	
	protected void Update (object sender, System.EventArgs a) {
		int x = int.Parse(spinbutton3.Text);
		int y = int.Parse(spinbutton4.Text);
		double next, next2;
		if (x >= 0 && x <= 15) {
			NextLevel.Text = (2*x + 7).ToString();
			next = ((x*x+6*x));
		}
		if (x >= 16 && x <= 30) {
			NextLevel.Text = (5*x - 38).ToString();
			next = ((2.5*x*x - 40.5*x + 360));
		}
		if (x >= 31) {
			NextLevel.Text = (9*x - 158).ToString();
			next = ((4.5*x*x - 162.5*x + 2220));
		}
		
		if (y >= 0 && y <= 15) {
			next2 = ((y*y+6*y));
		}
		if (y >= 16 && y <= 30) {
			next2 = ((2.5*y*y - 40.5*y + 360));
		}
		if (y >= 31) {
			next2 = ((4.5*y*y - 162.5*y + 2220));
		}
		
		NLevel.Text = (next - next2).ToString();
	}
}
