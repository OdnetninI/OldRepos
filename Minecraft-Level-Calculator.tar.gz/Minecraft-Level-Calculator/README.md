# Minecraft-Level-Calculator
Level Calculator for Minecraft.

BUILD
==============

Window
--------------
Use any compiler with C++ compatibility.

Linux
--------------
Use GNU C++ Compiler

g++ file.cpp

Mac
--------------
No Idea
