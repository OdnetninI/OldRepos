/*
  Copyright (c) OdnetninI (@OdnetninI) odnetnininds@gmail.com 2015
  GNU GPLv3+

  This program is free software: you can redistribute it and/or modify   
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <iostream>
#include <string>
#include <sstream>

/*
  From Minecraft Wiki: http://minecraft.gamepedia.com/Experience
 */
int TotalExperience (int level) {
  if (level >= 0 && level <= 15) return level*level + 6*level;
  if (level >= 16 && level <= 30) return 2.5*level*level - 40.5*level +360;
  if (level >= 31) return 4.5*level*level - 162.5*level + 2220;
  return 0;
}

int NextLevel (int level) {
  if (level >= 0 && level <= 15) return 2*level + 7;
  if (level >= 16 && level <= 30) return 5*level - 38;
  if (level >= 31) return 9*level - 158;
  return 0;
}

int main (int argc, char* argv[]) {

  if (argc == 3 || argc == 4) {
    if (argv[1][0] == 't') {
      std::string hello(argv[2]); 
      std::stringstream str(hello); 
      int x;  
      str >> x;  
      if (!str) {      
	return 1;      
      }
      std::cout << TotalExperience(x) << std::endl; 
    }
    else if (argv[1][0] == 'n') {
      std::string hello(argv[2]); 
      std::stringstream str(hello); 
      int x;  
      str >> x;  
      if (!str) {      
	return 1;      
      }
      std::cout << NextLevel(x) << std::endl;
    }
    else if (argv[1][0] == 'd') {
      std::string hello(argv[2]); 
      std::stringstream str(hello); 
      int x;  
      str >> x;  
      if (!str) {      
	return 1;      
      }
      std::string hello2(argv[3]); 
      std::stringstream str2(hello2); 
      int y;  
      str2 >> y;  
      if (!str2) {      
	return 1;      
      }
      if ( y > x)
	std::cout << TotalExperience(y) - TotalExperience(x)  << std::endl;
      else
	 std::cout << TotalExperience(x) - TotalExperience(y)  << std::endl;
    }
  }
  
  else {
    std::cout << "Bad Arguments\n" << "Usage:\n" << "LevelCalculator t 30\n" << "LevelCalculator n 30\n" << "LevelCalculator d 10 30\n";
    return 0;
  }
  

  
  return 0;
}


