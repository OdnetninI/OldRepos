/**
 * OdnetninI <odnetnininds@gmail.com>
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Copyright @OdnetninI 2016
*/

#include "ConfigSystem.hpp"
#include <iostream>

ConfigSystem::ConfigSystem () {
  this->data.clear();
}

ConfigSystem::ConfigSystem (const char* filename) {
  this->data.clear();
  this->load(filename);
}

void ConfigSystem::load (const char* filename) {
  std::ifstream file(filename);
  if (!file.good()) {
    std::cerr << "Could not open config File: " << filename << std::endl;
    return;
  }
  this->data.clear();

  file.seekg(file.beg);
  std::string key, value;
  char equals;
  while (file >> key >> equals >> value) {
    auto ret = this->data.insert(std::pair<std::string,std::string>(key, value));
    if (ret.second == false) ret.first->second = value;
  }
}

void ConfigSystem::setValue (const char* key, const char* value) {
  auto ret = this->data.insert(std::pair<std::string,std::string>(key, value));
  if (ret.second == false) ret.first->second = value;
}

std::string ConfigSystem::getValue (const char *key) {
  auto it = this->data.find(key);
  if (it != this->data.end()) return it->second;
  std::cerr << "Key not found: " << key << std::endl;
  return "";
}

void ConfigSystem::save (const char* filename) {
  std::ofstream file(filename);
  if (!file.good()) {
    std::cerr << "Could not create config File: " << filename << std::endl;
    return;
  }
  for (auto i = this->data.begin(); i != this->data.end(); i++)
    file << i->first << " = " << i->second << std::endl;
  file.close();
}
