# Simple-Config-System
A very Simple Config System
