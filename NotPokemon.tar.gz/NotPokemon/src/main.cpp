#include <SFML/Graphics.hpp>
#include <cstdint>

void insertTile (int x, int y, int tx, int ty, int tileSize, sf::VertexArray& vertex) {
  sf::Vertex ver;
  ver.position = sf::Vector2f(x*tileSize,y*tileSize);
  ver.texCoords = sf::Vector2f(tx*tileSize,ty*tileSize);
  vertex.append(ver);
  ver.position = sf::Vector2f(x*tileSize + tileSize,y*tileSize);
  ver.texCoords = sf::Vector2f(tx*tileSize + tileSize,ty*tileSize);
  vertex.append(ver);
  ver.position = sf::Vector2f(x*tileSize + tileSize,y*tileSize + tileSize);
  ver.texCoords = sf::Vector2f(tx*tileSize + tileSize,ty*tileSize + tileSize);
  vertex.append(ver);
  ver.position = sf::Vector2f(x*tileSize,y*tileSize + tileSize);
  ver.texCoords = sf::Vector2f(tx*tileSize,ty*tileSize + tileSize);
  vertex.append(ver);
}

#define SCALE_FACTOR 3

uint8_t pallet [18][20] {
  {2,2,2,2,2,2,2,2,2,2,2,1,1,2,2,2,2,2,2,2},
  {2,2,2,2,2,2,2,2,2,2,2,1,1,2,2,2,2,2,2,2},
  {2,2,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,2,2},
  {2,2,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,2,2},
  {2,2,4,4,5,1,5,1,5,1,4,4,5,1,5,1,5,1,2,2},
  {2,2,4,4,1,5,1,5,1,5,4,4,1,5,1,5,1,5,2,2},
  {2,2,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,2,2},
  {2,2,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,2,2},
  {2,2,5,1,4,4,4,4,5,1,5,1,5,1,5,1,5,1,2,2}
};
uint8_t pallet1 [18][20] {
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23},
  {23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,0,0,0,32,33,33,35,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,0,0,0,48,49,50,51,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,0,0,24,64,65,66,67,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
};

int main() {
  sf::RenderWindow window;
  sf::ContextSettings context;
  sf::View view (sf::FloatRect(0,0,160,144));
  context.antialiasingLevel = 0;
  window.create(sf::VideoMode(160*SCALE_FACTOR,144*SCALE_FACTOR), "NoPokemon", sf::Style::Default, context);
  window.setFramerateLimit(30);
  window.setView(view);

  sf::Texture texture;
  texture.loadFromFile("resources/tileset.png");
  sf::VertexArray vertex(sf::Quads);
  sf::VertexArray vertex2(sf::Quads);
  sf::RenderStates states;
  states.texture = &texture;

  for (int i = 0; i < 10; i++) {
    for (int j = 0; j < 9; j++) {
      insertTile (i, j, pallet[j][i]%16, pallet[j][i]/16, 16, vertex);
      insertTile (i, j, pallet1[j][i]%16, pallet1[j][i]/16, 16, vertex2);
    }
  }

  sf::Clock clock;
  clock.restart();

  while (window.isOpen()) {
    sf::Event event;
    while (window.pollEvent(event)) {
      if (event.type == sf::Event::Closed)
        window.close();
    }

    if (clock.getElapsedTime().asSeconds() > 0.10) {
      for (int i = 0; i < 4; i++) {
        vertex[i].texCoords.x += 16;
      }
      if (vertex[0].texCoords.x >= 256) {
        vertex[0].texCoords.x = 0;
        vertex[1].texCoords.x = 16;
        vertex[2].texCoords.x = 16;
        vertex[3].texCoords.x = 0;

        vertex[0].texCoords.y += 16;
        vertex[0].texCoords.y = (int)vertex[0].texCoords.y % 112;

        vertex[1].texCoords.y += 16;
        vertex[1].texCoords.y = (int)vertex[1].texCoords.y % 112;

        vertex[2].texCoords.y += 16;
        vertex[2].texCoords.y = (int)vertex[2].texCoords.y % 112;

        vertex[3].texCoords.y += 16;
        vertex[3].texCoords.y = (int)vertex[3].texCoords.y % 112;
      }
      clock.restart();
    }

    window.clear(sf::Color::Black);

    window.draw(vertex, states);
    window.draw(vertex2, states);

    window.display();
  }

  return 0;
}
