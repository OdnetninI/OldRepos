// Copyright (c) OdnetninI 2016-06-03
#ifndef __MAP_HPP__
#define __MAP_HPP__

#include <cstdint>
#include <list>

class Map {
	private:
		
	public:
		uint64_t minX, minY, maxX, maxY;
		std::list<Map*> adyacentes;
		
		Map(uint64_t minX, uint64_t maxX, uint64_t minY, uint64_t maxY) {
			this->minX = minX;
			this->minY = minY;
			this->maxX = maxX;
			this->maxY = maxY;
		}
		
		void addAyacente (Map* m) {
			this->adyacentes.push_back(m);
		}
};

#endif // __MAP_HPP__
