// Copyright (c) OdnetninI 2016-06-03
#include <iostream>

#include "MapPosFinder.hpp"

MapPosFinder mapFinder;

void search (int x, int y) {
	std::cout << "( " << x << ", " << y << ")" << std::endl;
	Map* r = mapFinder.buscar(x,y);
	if (!r) std::cout << "No encontrado" << std::endl;
	else std::cout << "Pertenece a: {( " << r->minX << ", " << r->maxX << "), ( " << r->minY << " ," << r->maxY << ")}" << std::endl;
}

int main (int argc, char* argv[]) {

	Map* a = new Map(9,12,0,7);
	Map* b = new Map(0,8,4,7);
	Map* c = new Map(0,8,0,3);
	Map* d = new Map(1,8,8,10);
	a->addAyacente(b);
	a->addAyacente(c);
	
	b->addAyacente(c);
	b->addAyacente(a);
	
	c->addAyacente(a);
	c->addAyacente(b);
	
	mapFinder.insertar(a);
	mapFinder.insertar(b);
	mapFinder.insertar(c);
	mapFinder.insertar(d);
	
	search(0,0);
	search(0,4);	
	search(3,2);
	search(1,9);	
	search(8,7);
	search(12,8);	
	search(13,7);
	
	delete a;
	delete b;
	delete c;
	delete d;

	return 0;
}

