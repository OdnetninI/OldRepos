#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>

sf::RenderWindow window;

void playMusic(const std::string& filename) {
    sf::Music music;
    if (!music.openFromFile("audio/" + filename))
        std::cerr << "Error opening music file: " << filename << "\n";
    music.play();
    while (music.getStatus() == sf::Music::Playing) {
        sf::sleep(sf::milliseconds(20));
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad0))
          music.stop();

        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                music.stop();
                window.close();
            }
        }
    }

}

int main (int argc, char* argv[]) {
  window.create(sf::VideoMode(200, 200), "Hatecraft Song Replay");
  window.setFramerateLimit(15);

  while (window.isOpen()){
    sf::Event event;
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            window.close();
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad1))
      playMusic("1.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad2))
      playMusic("2.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad3))
      playMusic("3.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad4))
      playMusic("4.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad5))
      playMusic("5.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad6))
      playMusic("6.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad7))
      playMusic("7.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad8))
      playMusic("8.ogg");
    else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad9))
      playMusic("9.ogg");

    window.clear(sf::Color::Black);
    window.display();
  }


  return 0;
}
